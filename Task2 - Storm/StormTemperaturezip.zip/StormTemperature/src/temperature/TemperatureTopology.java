package temperature;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.StormSubmitter;
import org.apache.storm.generated.AlreadyAliveException;
import org.apache.storm.generated.AuthorizationException;
import org.apache.storm.generated.InvalidTopologyException;
import org.apache.storm.topology.TopologyBuilder;

public class TemperatureTopology {

	public static void main(String[] args) throws InterruptedException, AlreadyAliveException, InvalidTopologyException, AuthorizationException {
		// TODO Auto-generated method stub
		Config cfg= new Config();
		cfg.setDebug(false);

		// Topologia DAG. 
		TopologyBuilder builder =new TopologyBuilder();
		
		builder.setSpout("DataSource", new SocketSpout());
		
		builder.setBolt("SamplingBoltReceiver", new SamplingBolt()).shuffleGrouping("DataSource");
		builder.setBolt("AlertBoltSender", new AlertBolt()).shuffleGrouping("DataSource");
		builder.setBolt("AlertLogBoltReceiver", new AlertLogBolt()).shuffleGrouping("AlertBoltSender");
		
		//invio topologia: 
		// 1) creazione local cluster

		
		LocalCluster cluster = new LocalCluster();
		cluster.submitTopology("TemperatureTopology",cfg, builder.createTopology());
		Thread.sleep(120000);
		cluster.shutdown();
		

		// 2) Storm Submitter
		//StormSubmitter.submitTopology("Topology",cfg, builder.createTopology());
	}

}
