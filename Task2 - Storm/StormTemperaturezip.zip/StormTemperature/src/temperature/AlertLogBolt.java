package temperature;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;

public class AlertLogBolt extends BaseRichBolt {

	private OutputCollector collector;
	private PrintWriter pw;

	@Override
	public void execute(Tuple arg0) {
		// TODO Auto-generated method stub
		// 1) lettura tupla e processing: "ID", "Location", "Temperature"
		long timestamp = arg0.getLongByField("timestamp");
		String location = arg0.getString(1);
		int temperature = arg0.getIntegerByField("temperature"); //se non ricordiamo il mapping tra la posizione e il count.


		//stampiamo il valore della tupla
		System.out.println("                ALERT LOG  "+ timestamp + ", " + location + ", " + temperature + "  da " +arg0.getSourceComponent() + " - " + arg0.getSourceStreamId());

		//Salvataggio delle tuple sul file alertfile.txt
		pw.println(timestamp +", " + location + ", " + temperature );
		pw.flush();

		//ack della tupla 
		collector.ack(arg0);
	}

	@Override
	public void prepare(Map arg0, TopologyContext arg1, OutputCollector arg2) {
		// TODO Auto-generated method stub
		collector=arg2;

		try {
			pw= new PrintWriter("/home/studente/alertfile.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer arg0) {

	}

}
