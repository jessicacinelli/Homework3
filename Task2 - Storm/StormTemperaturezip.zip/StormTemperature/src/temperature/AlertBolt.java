package temperature;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;

public class AlertBolt extends BaseRichBolt {

	private OutputCollector collector;
	private PrintWriter pw;
	
	@Override
	public void execute(Tuple arg0) {
		// TODO Auto-generated method stub
		// 1) lettura tupla
		int i = arg0.getIntegerByField("ID");
		String location = arg0.getString(1);
		int temperature = arg0.getIntegerByField("temperature"); 

		// stampiamo il valore della tupla
		System.out.println("      Bolt ricevuto "+ i + ", " + location + ", " + temperature + "  da " +arg0.getSourceComponent() + " - " + arg0.getSourceStreamId());

		//2) emit della tupla con temperatura maggiore di 35
		if(temperature >= 35){
			long timestamp=System.currentTimeMillis();
			collector.emit(new Values (timestamp, location, temperature)); 
			System.out.println( "               ALERT: "+ timestamp + ", " + location + ", " + temperature );

			//ack della tupla 
			collector.ack(arg0);
		}
	}
	
	@Override
	public void prepare(Map arg0, TopologyContext arg1, OutputCollector arg2) {
		// TODO Auto-generated method stub
		collector=arg2;
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer arg0) {
		// TODO Auto-generated method stub
		//definzione del formato della tupla emessa
		arg0.declare(new Fields("timestamp", "location", "temperature"));
	}
}
