package temperature;

import java.io.*;
import java.net.*;
import java.util.Map;

import org.apache.storm.spout.SpoutOutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichSpout;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;
import org.apache.storm.utils.Utils;

public class SocketSpout extends BaseRichSpout {

	private SpoutOutputCollector collector;

	private BufferedReader buf;
	@Override
	public void nextTuple() {
		String s= null;
		//impacchettiamo la stringa da inviare 
		try {
			s=buf.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//05/06/22 11:30:03 sensor: ID = 3 Room_C temperature 34
		//05/06/22 11:30:04 sensor: ID = 4 Floor_1 temperature 25
		//selezione dei campi
		String [] st =s.split(" ");
		int id= new Integer(st[5]);
		String location= st[6];
		int temperature = new Integer(st[8]);
		
		//Emit della tupla 
		collector.emit(new Values (id, location, temperature));
		System.out.println("spout: emesso: " + id+ ", " + location + ", " + temperature + " eseguito da " + Thread.currentThread().getName());

		Utils.sleep(1000);
	}

	@Override
	public void open(Map arg0, TopologyContext arg1, SpoutOutputCollector arg2) {
		// TODO Auto-generated method stub
		collector = arg2;
		try {
			Socket s =  new Socket ("127.0.0.1", 7777);

			//decorator che mettiamo intorno al reader
			buf= new BufferedReader(new InputStreamReader(s.getInputStream()));

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer arg0) {
		// TODO Auto-generated method stub
		//definzione del formato della tupla da emettere

		arg0.declare(new Fields("ID", "location", "temperature"));
	}

}
