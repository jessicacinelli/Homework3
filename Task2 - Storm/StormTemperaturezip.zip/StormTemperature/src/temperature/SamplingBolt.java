package temperature;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;

public class SamplingBolt extends BaseRichBolt {

	private OutputCollector collector;
	private PrintWriter pw;
	@Override

	public void execute(Tuple arg0) {
		// TODO Auto-generated method stub
		// 1) lettura tupla e processing: "ID", "Location", "Temperature"
		int i = arg0.getIntegerByField("ID");
		String location = arg0.getString(1);
		int temperature = arg0.getIntegerByField("temperature"); 


		//stampiamo il valore della tupla
		System.out.println("      Bolt ricevuto "+ i + ", " + location + ", " + temperature + "  da " +arg0.getSourceComponent() + " - " + arg0.getSourceStreamId());

		//Salvataggio delle tuple sul file logfile.txt
		//funzione di hash per campionare solo il 20% delle tuple ricevute
		int hash= Math.abs(i) % 5;
		if(hash == 0){
			pw.println(i +", " + location + ", " + temperature );
			pw.flush();
		}

		//ack della tupla 
		collector.ack(arg0);
	}

	@Override
	public void prepare(Map arg0, TopologyContext arg1, OutputCollector arg2) {
		// TODO Auto-generated method stub
		collector=arg2;

		try {
			pw= new PrintWriter("/home/studente/logfile.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer arg0) {
		
	}

}
