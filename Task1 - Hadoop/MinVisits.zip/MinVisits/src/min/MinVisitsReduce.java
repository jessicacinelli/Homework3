package min;

import java.io.IOException;
import java.util.*;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class MinVisitsReduce extends Reducer<Text, IntWritable,Text, IntWritable>{
	public List<Integer> listA = new ArrayList<Integer>();
	public void reduce(Text string, Iterable <IntWritable> list , Context ctx) throws IOException, InterruptedException {
		
		for(IntWritable value: list){
			listA.add(value.get());
		}
		int min = Collections.min(listA);
		ctx.write(string, new IntWritable(min));
		
	   
	}
}
