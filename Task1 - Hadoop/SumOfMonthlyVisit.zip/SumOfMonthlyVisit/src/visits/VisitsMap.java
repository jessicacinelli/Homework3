package visits;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;


public class VisitsMap extends Mapper<LongWritable, Text, Text, IntWritable>{

	public void map ( LongWritable key ,Text value ,Context ctx) throws IOException,InterruptedException{

		String[] st = value.toString().split(" ");

		if( st != null){
			String month = new String(st[0]);
			int  visits = new Integer(st[2]);

			ctx.write(new Text(month), new IntWritable(visits));
		}
	}

}
