package visits;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class VisitsReduce extends Reducer<Text, IntWritable,Text, IntWritable>{
	public void reduce(Text month, Iterable <IntWritable> list , Context ctx) throws IOException, InterruptedException {
		int sum = 0;
		for(IntWritable value: list){
			sum += value.get();
			
		}
		ctx.write(month, new IntWritable(sum));
		
	   
	}
}
