package sites;

import java.io.IOException;
import java.util.HashSet;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class SitesReduce extends Reducer<Text, Text,Text, IntWritable>{
	public HashSet<String> set = new HashSet<String>();
	public void reduce(Text site, Iterable <Text> list , Context ctx) throws IOException, InterruptedException {
		for(Text value: list){
			set.add(value.toString());
		}
		ctx.write(site, new IntWritable(set.size()));
	}
}
