package sites;

import java.io.IOException;
import java.util.*;
import java.util.Map.*;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class SitesMap extends Mapper<LongWritable, Text, Text, Text>{

	public void map ( LongWritable key ,Text value ,Context ctx) throws IOException,InterruptedException{
		
		String[] st = value.toString().split(" ");

		if( st != null){
			String sites = new String(st[1]);
			ctx.write(new Text("distsites"), new Text(sites));
		}
	}
}
